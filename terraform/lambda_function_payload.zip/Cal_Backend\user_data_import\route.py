import json
import uuid
import os
import base64
from datetime import datetime, timezone
from typing import Any, Dict, List
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, UploadFile, status
from fastapi.responses import FileResponse
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from Cal_Backend.db.main import get_session
from Cal_Backend.db.models import ImportJob, ImportJobStatus, User
from Cal_Backend.db.redis import get_job_status, set_job_status
from Cal_Backend.auth.dependencies import get_current_userC, AccessTokenBearerC, TokenBearer
from Cal_Backend.Conversations.schemas import ConversationResponse

from .notesimportschemas import GoogleKeepImportRequest
from .service import validate_import_data, ImportService
from .schemas import ExtensionIngestSchema, ImportConversationSchema

Json_router = APIRouter()
ACCESS_TOKEN_BEARER = AccessTokenBearerC()
HEADER_TOKEN_BEARER = TokenBearer(cookie_name="access_token", auto_error=True)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _save_to_local_disk(data: List[ImportConversationSchema]):
    """
    Temporarily save extension data to local disk for debugging.
    Saves JSON to data.txt and images to an images/ folder.
    Handles a list of conversations (the extension format).
    """
    try:
        # Use absolute path as requested
        base_path = r"C:\Users\shubh\Desktop\Calendar_By_Kla\extension feeds"
        
        # Ensure base directory exists
        if not os.path.exists(base_path):
            os.makedirs(base_path, exist_ok=True)
            
        for conv in data:
            # Create a unique folder for this conversation ingestion
            timestamp_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            folder_name = f"feed_{timestamp_str}_{str(uuid.uuid4())[:8]}"
            feed_dir = os.path.join(base_path, folder_name)
            os.makedirs(feed_dir, exist_ok=True)
            
            # 1. Save the text/JSON data
            text_file = os.path.join(feed_dir, "data.txt")
            with open(text_file, "w", encoding="utf-8") as f:
                # Use model_dump_json for Pydantic models
                f.write(conv.model_dump_json(indent=2))
                
            # 2. Save images if any (extension original format: inside metadata.images)
            images_saved = 0
            for i, msg in enumerate(conv.messages):
                # Extension puts images in metadata.images
                images = msg.metadata.get("images", [])
                if images:
                    images_dir = os.path.join(feed_dir, "images")
                    if not os.path.exists(images_dir):
                        os.makedirs(images_dir, exist_ok=True)
                    
                    for j, img in enumerate(images):
                        img_data = img.get("data")
                        if not img_data:
                            continue
                            
                        # Handle base64 prefix if present
                        prefix = ""
                        if "," in img_data:
                            prefix, img_data = img_data.split(",", 1)
                        
                        try:
                            binary_data = base64.b64decode(img_data)
                            
                            # Determine extension from prefix or filename or default
                            ext = "png"
                            if "image/jpeg" in prefix or "image/jpg" in prefix:
                                ext = "jpg"
                            elif "image/webp" in prefix:
                                ext = "webp"
                            elif "image/gif" in prefix:
                                ext = "gif"
                            else:
                                # Try to get from filename if provided
                                filename = img.get("filename", "")
                                if "." in filename:
                                    ext = filename.split(".")[-1].lower()
                            
                            if len(ext) > 4: ext = "png"
                            
                            # Use provided filename or generate one
                            base_filename = img.get("filename", f"msg_{i}_img_{j}").split(".")[0]
                            img_filename = f"{base_filename}.{ext}"
                            
                            with open(os.path.join(images_dir, img_filename), "wb") as f:
                                f.write(binary_data)
                            images_saved += 1
                        except Exception as img_err:
                            print(f">>> [DEBUG] ERROR decoding image: {img_err}")
                            
            print(f">>> [DEBUG] SAVED EXTENSION FEED: {feed_dir} (Images: {images_saved})")
    except Exception as e:
        print(f">>> [DEBUG] ERROR saving extension feed to disk: {e}")


async def _dispatch_import(
    session: AsyncSession,
    background_tasks: BackgroundTasks,
    user: User,
    job_type: str,
    data: list,
) -> dict:
    """
    Creates an ImportJob record and dispatches work.

    Production (SQS_IMPORT_QUEUE_URL set):
        Serialises data → S3, sends SQS message, returns immediately.

    Local dev (SQS not configured):
        Schedules work via FastAPI BackgroundTasks, returns immediately.
    """
    from Cal_Backend.config import get_settings
    settings = get_settings()

    total = len(data)
    job_id = str(uuid.uuid4())

    job = ImportJob(
        id=UUID(job_id),
        user_id=user.id,
        job_type=job_type,
        status=ImportJobStatus.PENDING,
        total_items=total,
    )
    session.add(job)
    await session.commit()

    await set_job_status(job_id, {
        "job_id": job_id,
        "status": "pending",
        "total_items": total,
        "processed_items": 0,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    })

    if settings.SQS_IMPORT_QUEUE_URL and settings.S3_BUCKET_NAME:
        from Cal_Backend.storage.s3 import upload_import_data
        from Cal_Backend.queue.sqs import enqueue_import_job

        s3_key = f"imports/{user.id}/{job_id}/data.json"
        payload = json.dumps({"data": [
            item if isinstance(item, dict) else item.model_dump()
            for item in data
        ]}).encode()

        await upload_import_data(payload, s3_key)

        result = await session.execute(
            select(ImportJob).where(ImportJob.id == UUID(job_id))
        )
        job_rec = result.scalar_one_or_none()
        if job_rec:
            job_rec.s3_key = s3_key
            session.add(job_rec)
            await session.commit()

        await enqueue_import_job(job_id, s3_key, str(user.id), job_type)
    else:
        from Cal_Backend.user_data_import.worker import process_import_job
        # Serialise to plain dicts so the worker can reconstruct models
        serialisable = [
            item if isinstance(item, dict) else item.model_dump()
            for item in data
        ]
        background_tasks.add_task(
            process_import_job,
            job_id, str(user.id), job_type,
            in_memory_data=serialisable,
        )

    return {
        "job_id": job_id,
        "status": "pending",
        "total_items": total,
        "message": f"Import queued. {total} items to process.",
        "poll_url": f"/api/v1/ArjunJson/import/status/{job_id}",
    }


# ---------------------------------------------------------------------------
# Status / listing endpoints
# ---------------------------------------------------------------------------

@Json_router.get("/import/status/{job_id}")
async def get_import_status(
    job_id: str,
    current_user: User = Depends(get_current_userC),
    session: AsyncSession = Depends(get_session),
):
    """Poll the status of an async import job."""
    cached = await get_job_status(job_id)
    if cached:
        return cached

    result = await session.execute(
        select(ImportJob).where(
            ImportJob.id == UUID(job_id),
            ImportJob.user_id == current_user.id,
        )
    )
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Import job not found")

    return {
        "job_id": str(job.id),
        "status": job.status.value,
        "total_items": job.total_items,
        "processed_items": job.processed_items,
        "result_stats": job.result_stats,
        "error": job.error_message,
        "updated_at": job.updated_at.isoformat(),
    }


@Json_router.get("/import/jobs")
async def list_import_jobs(
    current_user: User = Depends(get_current_userC),
    session: AsyncSession = Depends(get_session),
):
    """List the 20 most recent import jobs for the current user."""
    result = await session.execute(
        select(ImportJob)
        .where(ImportJob.user_id == current_user.id)
        .order_by(ImportJob.created_at.desc())
        .limit(20)
    )
    jobs = result.scalars().all()
    return [
        {
            "job_id": str(j.id),
            "status": j.status.value,
            "job_type": j.job_type,
            "total_items": j.total_items,
            "processed_items": j.processed_items,
            "created_at": j.created_at.isoformat(),
            "updated_at": j.updated_at.isoformat(),
            "result_stats": j.result_stats,
        }
        for j in jobs
    ]


# ---------------------------------------------------------------------------
# Import endpoints — all return 202 immediately
# ---------------------------------------------------------------------------

@Json_router.post("/extension/ingest", status_code=status.HTTP_202_ACCEPTED)
async def ingest_from_extension(
    data: List[ImportConversationSchema],
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_userC),
    session: AsyncSession = Depends(get_session),
):
    """
    Ingest conversations from the browser extension with deduplication.
    Processed asynchronously to handle potentially large message histories.
    """
    print(f">>> [DEBUG] Extension ingest received for {len(data)} conversations")
    
    # Temporarily save to local disk for debugging
    _save_to_local_disk(data)

    # Wrap in a list for _dispatch_import
    # Convert models to dicts for the dispatcher
    serialisable = [conv.model_dump() for conv in data]
    
    return await _dispatch_import(
        session, background_tasks, current_user,
        "extension_ingest", serialisable
    )


@Json_router.post("/json", status_code=status.HTTP_202_ACCEPTED)
async def import_from_json(
    data: List[Dict[str, Any]],
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_userC),
    session: AsyncSession = Depends(get_session),
):
    """Queue an import from cleaned conversation JSON. Returns job_id to poll."""
    validated = validate_import_data(data)
    return await _dispatch_import(session, background_tasks, current_user, "json", validated)


@Json_router.post("/upload", status_code=status.HTTP_202_ACCEPTED)
async def import_from_file(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_userC),
    session: AsyncSession = Depends(get_session),
):
    """Queue an import from an uploaded JSON file."""
    if not file.filename.endswith(".json"):
        raise HTTPException(status_code=400, detail="Only JSON files are accepted")

    try:
        content = await file.read()
        data = json.loads(content.decode("utf-8"))
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON file")

    validated = validate_import_data(data)
    return await _dispatch_import(session, background_tasks, current_user, "json", validated)


@Json_router.post("/google-keep", status_code=status.HTTP_202_ACCEPTED)
async def import_google_keep(
    request: GoogleKeepImportRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_userC),
    session: AsyncSession = Depends(get_session),
):
    """Queue a Google Keep import from a JSON request body."""
    return await _dispatch_import(
        session, background_tasks, current_user,
        "google_keep", request.notes,
    )


@Json_router.post("/google-keep/file", status_code=status.HTTP_202_ACCEPTED)
async def import_google_keep_file(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_userC),
    session: AsyncSession = Depends(get_session),
):
    """Queue a Google Keep import from an uploaded JSON file."""
    if not file.filename.endswith(".json"):
        raise HTTPException(status_code=400, detail="Only JSON files are accepted")

    try:
        content = await file.read()
        data = json.loads(content.decode("utf-8"))
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON file")

    request = GoogleKeepImportRequest(notes=data)
    return await _dispatch_import(
        session, background_tasks, current_user,
        "google_keep", request.notes,
    )


@Json_router.post("/google-keep/bulk", status_code=status.HTTP_202_ACCEPTED)
async def bulk_import_google_keep(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...),
    current_user: User = Depends(get_current_userC),
    session: AsyncSession = Depends(get_session),
):
    """
    Queue a bulk Google Keep import from multiple JSON files.
    All files are normalised and merged into a single job.
    """
    if not files:
        raise HTTPException(status_code=400, detail="No files provided")

    invalid = [f.filename for f in files if not f.filename.endswith(".json")]
    if invalid:
        raise HTTPException(
            status_code=400,
            detail=f"Non-JSON files rejected: {', '.join(invalid)}",
        )

    combined_notes = []
    for file in files:
        try:
            content = await file.read()
            data = json.loads(content.decode("utf-8"))
        except json.JSONDecodeError:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid JSON in file: {file.filename}",
            )

        if isinstance(data, dict) and "notes" in data:
            notes_raw = data["notes"]
        elif isinstance(data, list):
            notes_raw = data
        elif isinstance(data, dict):
            notes_raw = [data]
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Unrecognised structure in {file.filename}",
            )

        from .notesimportschemas import GoogleKeepNote
        for raw_note in notes_raw:
            try:
                combined_notes.append(GoogleKeepNote(**raw_note))
            except Exception as exc:
                raise HTTPException(
                    status_code=422,
                    detail=f"Invalid note in {file.filename}: {exc}",
                )

    if not combined_notes:
        raise HTTPException(status_code=400, detail="No notes found across all files")

    return await _dispatch_import(
        session, background_tasks, current_user,
        "google_keep_bulk", combined_notes,
    )


# ---------------------------------------------------------------------------
# Read-only / utility endpoints (unchanged)
# ---------------------------------------------------------------------------

@Json_router.get("/history", response_model=List[ConversationResponse])
async def get_import_history(
    source: str = None,
    limit: int = 50,
    offset: int = 0,
    current_user: User = Depends(get_current_userC),
    session: AsyncSession = Depends(get_session),
):
    from sqlmodel import select, func
    from Cal_Backend.db.models import Conversation, Note

    statement = select(Conversation).where(Conversation.user_id == current_user.id)

    if source:
        from Cal_Backend.db.models import NotebookSource
        try:
            source_enum = NotebookSource(source.lower())
            statement = statement.where(Conversation.source == source_enum)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid source: {source}")

    statement = statement.order_by(Conversation.import_date.desc()).offset(offset).limit(limit)
    result = await session.execute(statement)
    conversations = result.scalars().all()

    output = []
    for conv in conversations:
        count_result = await session.execute(
            select(func.count(Note.id)).where(Note.conversation_id == conv.id)
        )
        note_count = count_result.scalar_one()
        conv_dict = ConversationResponse.model_validate(conv).model_dump()
        conv_dict["note_count"] = note_count
        output.append(ConversationResponse(**conv_dict))

    return output


@Json_router.get("/google-keep/bulk/status")
async def get_bulk_import_status(
    current_user: User = Depends(get_current_userC),
    session: AsyncSession = Depends(get_session),
):
    from sqlmodel import select, func
    from Cal_Backend.db.models import Note

    total_result = await session.execute(
        select(func.count(Note.id)).where(Note.user_id == current_user.id)
    )
    total_notes = total_result.scalar_one()

    keep_result = await session.execute(
        select(func.count(Note.id)).where(
            Note.user_id == current_user.id,
            Note.notemetadata["import_source"].astext == "google_keep",
        )
    )
    keep_notes = keep_result.scalar_one()

    return {
        "total_notes": total_notes,
        "google_keep_notes": keep_notes,
        "other_notes": total_notes - keep_notes,
    }


@Json_router.get("/google-keep/bulk/download-report/{filename}")
async def download_failure_report(
    filename: str,
    current_user: User = Depends(get_current_userC),
):
    import tempfile

    if not filename.startswith("import_failures_") or not filename.endswith(".txt"):
        raise HTTPException(status_code=400, detail="Invalid report filename")

    report_path = os.path.join(tempfile.gettempdir(), filename)
    if not os.path.exists(report_path):
        raise HTTPException(status_code=404, detail="Report file not found or expired")

    return FileResponse(
        path=report_path,
        media_type="text/plain",
        filename=filename,
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
